from django.contrib import admin
from .models import QuestionCard

admin.site.register(QuestionCard)
